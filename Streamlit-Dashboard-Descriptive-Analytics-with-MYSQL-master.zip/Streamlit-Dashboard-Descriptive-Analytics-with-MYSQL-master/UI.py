import streamlit as st
def UI():
    st.markdown("""<h3 style="color:#002B50;">⚛  BUSINESS ANALYTICS DASHBOARD</h3>""", unsafe_allow_html=True)